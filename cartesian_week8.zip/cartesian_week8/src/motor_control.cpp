#include "motor_control.h"
#include "path_functions.h"
#include "websocket.h"

#include <Arduino.h>
#include <AccelStepper.h>
#include <stdint.h>

#include <Servo.h>

Servo myservo1; 
Servo myservo2; 

#define MOTORX_STEP_PIN 2
#define MOTORX_DIR_PIN 5
#define MOTORY_STEP_PIN 3
#define MOTORY_DIR_PIN 6
#define MOTORZ_STEP_PIN 4
#define MOTORZ_DIR_PIN 7

#define LIMITSWITCHX_PIN 9
#define LIMITSWITCHY_PIN 10
#define LIMITSWITCHZ_PIN 11
#define INTERRUPT_PIN 99

int MICROSTEP_RES = 16;
int STEPRATE = 50;
int STEP_INCREMENT = 100;
int TO_MILLI = 10;

float WORKSPACE_MAX_X = 180.00;
float WORKSPACE_MAX_Y = 185.00;
float WORKSPACE_MAX_Z = 160.00;

float REDZONE_MIN_X = 2.5;
float REDZONE_MAX_X = 15;
float REDZONE_MIN_Y = 12;
float REDZONE_MAX_Y = 18;

volatile bool INTERRUPT_FLAG = false;

AccelStepper MOTORX(AccelStepper::DRIVER, MOTORX_STEP_PIN, MOTORX_DIR_PIN);
AccelStepper MOTORY(AccelStepper::DRIVER, MOTORY_STEP_PIN, MOTORY_DIR_PIN);
AccelStepper MOTORZ(AccelStepper::DRIVER, MOTORZ_STEP_PIN, MOTORZ_DIR_PIN);

/////////////////////////////////////////////////////////////////////
void motorSetup(uint16_t maxSpeed, uint16_t maxAccel)
{
  pinMode(LIMITSWITCHX_PIN, INPUT_PULLUP);
  pinMode(LIMITSWITCHY_PIN, INPUT_PULLUP);
  pinMode(LIMITSWITCHZ_PIN, INPUT_PULLUP);
  // pinMode(INTERRUPT_PIN, INPUT_PULLUP);                                         // ตั้งค่า pin X สำหรับ interrupt
  // attachInterrupt(digitalPinToInterrupt(INTERRUPT_PIN), resetBoard(), FALLING); // ใช้ interrupt บน pin X
 
  MOTORX.setMaxSpeed(maxSpeed);
  MOTORY.setMaxSpeed(maxSpeed);
  MOTORZ.setMaxSpeed(maxSpeed);
  MOTORX.setAcceleration(maxAccel);
  MOTORY.setAcceleration(maxAccel); 
  MOTORZ.setAcceleration(maxAccel);

  myservo1.attach(12);
  myservo2.attach(13);
}
/////////////////////////////////////////////////////////////////////
// bool isInRedZone(float x, float y)
// {
//   return x >= REDZONE_MIN_X && x <= REDZONE_MAX_X && y >= REDZONE_MIN_Y && y <= REDZONE_MAX_Y;
// }

/////////////////////////////////////////////////////////////////////
void homePosition()
{
  //------------Z Process -------------// รัน Z ก่อนเพื่อนกันชนกับstamper
  MOTORZ.setSpeed(-3000);
  while (digitalRead(LIMITSWITCHZ_PIN) == HIGH)
  {
    MOTORZ.runSpeed();
  }

  MOTORZ.setCurrentPosition(0);
  //------------Y Process -------------// รัน Y ก่อนเพื่อนกันชนกับกล้องตอนSethome
  MOTORY.setSpeed(-3000);
  while (digitalRead(LIMITSWITCHY_PIN) == HIGH)
  {
    MOTORY.runSpeed();
  }
  MOTORY.setCurrentPosition(0);

  //------------X Process -------------//
  MOTORX.setSpeed(-3000);
  while (digitalRead(LIMITSWITCHX_PIN) == HIGH)
  {
    MOTORX.runSpeed();
  }
  MOTORX.setCurrentPosition(0);

  //----------------------------------//
  moveTomm(3, 3, 3);
  MOTORX.setCurrentPosition(0);
  MOTORY.setCurrentPosition(0);
  MOTORZ.setCurrentPosition(0);
  Serial.println("Sethome position");
  delay(1000);
}

/////////////////////////////////////////////////////////////////////
void moveTomm(float targetX, float targetY, float targetZ)
{
  if (targetX <= WORKSPACE_MAX_X && targetY <= WORKSPACE_MAX_Y && targetZ <= WORKSPACE_MAX_Z)
  {
    MOTORX.setSpeed(10000);
    MOTORY.setSpeed(10000);
    MOTORZ.setSpeed(10000);

    float stepsX = targetX * MICROSTEP_RES * STEPRATE / TO_MILLI;
    float stepsY = targetY * MICROSTEP_RES * STEPRATE / TO_MILLI;
    float stepsZ = targetZ * MICROSTEP_RES * STEPRATE / TO_MILLI;

    // float redzoneStep_X_Min = REDZONE_MIN_X * (MICROSTEP_RES * STEPRATE);
    // float redzoneStep_X_Max = REDZONE_MAX_X * (MICROSTEP_RES * STEPRATE);
    // float redzoneStep_Y_Min = REDZONE_MIN_Y * (MICROSTEP_RES * STEPRATE);
    // float redzoneStep_Y_Max = REDZONE_MAX_Y * (MICROSTEP_RES * STEPRATE);

    MOTORX.moveTo(stepsX);
    MOTORY.moveTo(stepsY);
    MOTORZ.moveTo(stepsZ);
    
    while (MOTORX.distanceToGo() != 0 || MOTORY.distanceToGo() != 0 || MOTORZ.distanceToGo() != 0)
    {
      if (INTERRUPT_FLAG)
      {
        interruptLoop();
        Serial.println("Cartesian was interrupted..!");
        resetBoard();
      }
      else
      {
        MOTORX.run();
        MOTORY.run();
        MOTORZ.run();
      }
    }

    Serial.print("X: ");
    Serial.print(targetX);
    Serial.print(" mm, ");
    Serial.print("y: ");
    Serial.print(targetY);
    Serial.print(" mm, ");
    Serial.print("Z: ");
    Serial.print(targetZ);
    Serial.println(" mm");
  }
  else
  {
    Serial.print("Error: Coordinate X");
    Serial.print(targetX);
    Serial.print(" Y");
    Serial.print(targetY);
    Serial.print(" Z");
    Serial.println(targetZ);
    Serial.println(" *[Exceeds the defined limits X < 180, Y < 180, Z < 160]");
  }
}

void Gripped(float pos)
{

  myservo1.write(pos);    // 50 [ grasp ] --- 120 [ release ]
   
}

void Rotate (float pos)
{

  myservo2.write(pos);  // 9 [ 0 deg.]  --- 102 [ 90 deg.]      

}

/////////////////////////////////////////////////////////////////////
void interruptLoop()
{
    INTERRUPT_FLAG = true; // ตั้งค่าสถานะให้หยุด loop
}

/////////////////////////////////////////////////////////////////////
void resetBoard()
{
  Serial.println("Arduino reset...");
  delay(1000);
  asm volatile("  jmp 0"); // คำสั่ง Assembly สำหรับรีเซ็ตบอร์ด
}

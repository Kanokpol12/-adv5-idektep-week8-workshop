#include "Motor.h"

Motor::Motor(int Pin1, int Pin2)
{
    mPin1 = Pin1;
    mPin2 = Pin2;
}

void Motor::motorInit()
{
    pinMode(mPin1, OUTPUT);
    pinMode(mPin2, OUTPUT);
}

void Motor::conveyorOn()
{
    digitalWrite(mPin1, HIGH);
    digitalWrite(mPin2, LOW);
}

void Motor::conveyorOff()
{
    digitalWrite(mPin1, LOW);
    digitalWrite(mPin2, LOW);
}